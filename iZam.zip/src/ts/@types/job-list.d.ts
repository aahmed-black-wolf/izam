type JobData = {
  title: string;
  company: string;
  location: string;
  timePosted: string;
  experience: string;
  jobType: string;
  workFormat: string;
  field: string;
  companyLogo: string;
};
